using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ButtonTextColorMng : MonoBehaviour {

//	[SerializeField]
//	public bool IsAlphaOnly = true;
//
//	[SerializeField]
//	public Button TargetButton;
//
//	private Text ThisText;
//
//	void Awake(){
//		if (TargetButton == null) {
//			TargetButton = GetComponentInParent<Button> ();
//		}
//		ThisText = GetComponent<Text> ();
//	}
//
//	// Use this for initialization
//	void Start () {
//		setColor ();
//	}
//
//	void Update(){
//		setColor ();
//	}
//
//	public void setColor(){
//		if (IsAlphaOnly) {
//			Color col = ThisText.color;
//			if (col.a != TargetButton.image.color.a) {
//				col.a = TargetButton.image.color.a;
//				ThisText.color = col;
//			}
//		} else {
//			if (ThisText.color != TargetButton.image.color) {
//				ThisText.color = TargetButton.image.color;
//			}
//		}
//	}
	

}
