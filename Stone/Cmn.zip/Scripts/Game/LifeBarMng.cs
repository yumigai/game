using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 紛らわしくなるので別名化
/// </summary>
public class LifeBarMng : GaugeBarMng
{
}
