using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RelationObjectMng : MonoBehaviour
{
    [SerializeField,Header("別オブジェクトとの関連付け")]
    public List<GameObject> Relation;

}
