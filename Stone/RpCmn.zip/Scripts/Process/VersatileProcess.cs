﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class VersatileProcess
{
    public static void nextDay() {

        if (GameConst.IS_TIME_LIMIT_SYSTEM) {
            SaveMng.Status.RestTimeLimit--;
            SaveMng.Status.save();
        }

        SaveMng.Quest = new QuestTran();
        SaveMng.Quest.save();
        SceneManagerWrap.LoadScene(CmnConst.SCENE.HomeScene);

    }
}
