using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RelicSkillMast : MasterCmn
{
    public uint Id;

    public string RelicTag;

    public string SkillTag;

    public int LeanLv;
}

