using UnityEngine;
using System.Collections;

public class BlankAnimationMng : MonoBehaviour {

	public void meleeAttackSe()
	{
	}
	public void gunFire()
	{
	}

	public void attackStart()
	{
	}

	public void moveStart(){

	}

	public void meleeHitStart()
	{

	}

	public void meleeHitEnd()
	{
	}
	public void meleeAttackFinish()
	{
	}

	public void attackFinish()
	{
	}

	public void downSe()
	{
	}

	public void deadEndAnime()
	{
	}
	public void idleStart(){
	}
}
