﻿using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class Item : UIBehaviour 
{
	virtual public void UpdateItem(int count) 
	{
	}
}
