using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// ボタンの表示、入力可・不可を制御する（現状使わない？）
/// </summary>
public class ButtonControllMng : MonoBehaviour
{
    [SerializeField]
    public ButtonMng[] Buttons;

}
