using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GuidTargetMng : MonoBehaviour {

    //コンポーネント検索用の空オブジェクト
}
