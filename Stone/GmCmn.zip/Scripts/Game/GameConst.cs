using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 空クラス（各ゲームで用意するクラスだが基本ライブラリで宣言することがあるため）
/// </summary>
public partial class GameConst : CmnConst
{
    // Start is called before the first frame update
}
