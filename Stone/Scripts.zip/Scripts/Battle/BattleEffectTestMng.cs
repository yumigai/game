﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BattleEffectTestMng : MonoBehaviour
{
    [SerializeField]
    private Transform[] Units;

    [SerializeField]
    private Transform[] Enemys;

    [SerializeField]
    private Transform EffectBase;

    [SerializeField]
    private Camera EffectCamera;

    [SerializeField]
    private GameObject EffectButton;

    private EffectMng[] Effects;

    private bool isAuto = true;

    private int Count = 0;

    private EffectMng SelectEffect;

    private Vector3 EffectPosision = new Vector3();

    // Start is called before the first frame update
    void Start()
    {
        Effects = EffectBase.GetComponentsInChildren<EffectMng>();

        for (int i = 0; i < Effects.Length; i++) {
            var obj = Instantiate(EffectButton) as GameObject;
            //obj.GetComponent<Button>().onClick.AddListener(()=>PushSelectedEffect(obj.transform.GetSiblingIndex()));
            obj.GetComponentInChildren<Text>().text = Effects[i].name;
            obj.transform.SetParent(EffectButton.transform.parent);
            obj.SetActive(true);
            obj.transform.localScale = EffectButton.transform.localScale;
            
        }
        EffectButton.SetActive(false);

        //StartCoroutine(autoEffect());
    }

    private IEnumerator repeatEffect() {
        for (int i = 0; i < 6; i++) {
            SelectEffect.effect(EffectPosision);
            yield return new WaitForSeconds(1f);
        }
    }

    //private IEnumerator autoEffect() {
    //    for (int i = 0; i < 100 && isAuto; i++) {

    //        yield return new WaitForSeconds(0.5f);
    //        if (Count < Units.Length) {
    //            PushUnitEffect(Count);
    //        } else  {
    //            var eneIndex = Count - Units.Length;
    //            if (eneIndex < Enemys.Length) {
    //                PushEnemyEffect(eneIndex);
    //            } else {
    //                Count = 0;
    //            }
    //        }
    //        Count++;
    //    }
    //}

    //public void PushAuto() {
    //    isAuto = !isAuto;
    //    if (isAuto) {
    //        StartCoroutine(autoEffect());
    //    }
    //}

    public void PushSelectedEffect(Transform t) {
        int index = t.GetSiblingIndex() - 1;
        SelectEffect = Effects[index];
        //SelectEffect.effect(EffectPosision);
        StartCoroutine(repeatEffect());
    }

    public void PushUnitEffect( int index ) {
        EffectPosision = changeScreenPosi(Units[index].position);
        SelectEffect.effect(EffectPosision);
    }

    public void PushEnemyEffect( int index ) {
        EffectPosision = changeScreenPosi(Enemys[index].position);
        SelectEffect.effect(EffectPosision);
    }

    private Vector3 changeScreenPosi( Vector3 effect_point) {
        return UtilToolLib.changeScreenPosi(EffectCamera, effect_point);
    }
}
