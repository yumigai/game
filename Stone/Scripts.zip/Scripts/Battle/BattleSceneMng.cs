﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class BattleSceneMng : BaseBattleSceneMng
{


    [SerializeField]
    private CameraFilterPack_Broken_Screen BrokenFilter;

    [SerializeField]
    private CameraFilterPack_Drawing_BluePrint BluePrintFilter;

    new public static BattleSceneMng Singleton;

    void Awake() {
        Singleton = this;
        BaseBattleSceneMng.Singleton = this;
        base.init();
    }

    private void Start() {
    }

    new public void OnEnable() {

        initSetting();
    }

    override protected void initSetting() {
        BrokenFilter.Fade = 1f;
        BluePrintFilter.enabled = false;
        base.initSetting();
    }

    private IEnumerator changeBattleScene() {
        yield return new WaitForSeconds(0.1f);
        StartCoroutine(CameraScreenShotMng.TakeAndGetScreenShot((Sprite sp) => {
            EncountScreen.sprite = sp;
            EncountScreen.gameObject.SetActive(true);
            BaseBattleSceneMng.Singleton.SceneBase.SetActive(true);
            SceneBase.SetActive(false);
        }));
    }

    protected override IEnumerator EncountAnimation() {
        yield return new WaitForEndOfFrame();
        yield return new WaitForSeconds(1f);
        EncountScreen.CrossFadeAlpha(0, 3, true);
        for (var i = 0; i < 100; i++) {
            BrokenFilter.Fade -= 0.01f;
            yield return new WaitForSeconds(0.02f);
        }
        EncountScreen.gameObject.SetActive(false);
        BaseBattleSceneMng.Sequence = SEQUENCE.ADVANCE;

        SoundMng.Instance.playBGM(BattleBgm);

    }

    protected override IEnumerator ResultProcess() {

        yield return new WaitForSeconds(2.5f);

        if (BattleResult == BattleProc.RESULT.WIN) {

            BluePrintFilter.enabled = true;
            yield return new WaitForSeconds(1f);
            ResultBoard.SetActive(true);

            ResultExp.AnimationStart(0, BattleProc.Reward.GetExp);
            ResultMoney.AnimationStart(0, BattleProc.Reward.GetMoney);

            ResultNowMoney.text = SaveMng.Status.Money.ToString();

            ResultItemList.clear();
            for (int i = 0; i < BattleProc.Reward.GetItems.Count; i++) {
                var tran = BattleProc.Reward.GetItems[i];
                var item = ResultItemList.makeListItemMasterId(i, tran.Mst);
                item.Name.color = CommonProcess.getRareColor(tran.Rarity);
            }

            setUnitExp();
        } else {
            BluePrintFilter.enabled = true;
            yield return new WaitForSeconds(1f);
            LoseBoard.SetActive(true);
        }
    }

    /// <summary>
    /// デバッグ用
    /// </summary>
    public void forceResultProcess() {
        EnemyParty.Members.ForEach(it => it.Unit.damage(99999));
        ResultBoard.SetActive(false);
        BluePrintFilter.enabled = false;
        StartCoroutine(ResultProcess());
    }
}
