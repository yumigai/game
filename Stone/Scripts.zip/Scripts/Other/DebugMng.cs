﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
using System.Linq;

#if UNITY_EDITOR_WIN
using UnityEditor;
using UnityEditor.SceneManagement;
using System.Threading.Tasks;
using UnityEngine.SceneManagement;
#endif

public class DebugMng : CmnDebugMng {
#if UNITY_EDITOR_WIN
    [MenuItem("Custom/debug/writeSave")]
    public static void writeSave() {

        writeSave(SaveMng.Status.GetType().Name);
        writeSave(SaveMng.UnitData.GetType().Name);
        writeSave(SaveMng.ItemData.GetType().Name);
        if (SaveMng.Quest != null) {
            writeSave(SaveMng.Quest.GetType().Name);
        }

    }

    private static void writeSave(string name) {
        string data = PlayerPrefs.GetString(name);
        UtilToolLib.writeText("savelog/" + name + ".txt", data);
        Debug.Log(name);
    }

    [MenuItem("Custom/debug/readSave")]
    public static void loasSave() {
        SaveMng.Status = loasSave<PlayerStatusTran>(SaveMng.Status.GetType().Name);
        SaveMng.UnitData = loasSave<SaveMng.UnitWrap>(SaveMng.UnitData.GetType().Name);
    }

    private static T loasSave<T>(string name) {
        Debug.Log(name);
        string json = UtilToolLib.readText("savelog/" + name + ".txt");
        return JsonUtility.FromJson<T>(json);

    }

    [MenuItem("Custom/debug/allData/allItem")]
    public static void allItem() {
        SaveMng.Items.Clear();
        foreach (var item in ItemMast.List) {
            SaveMng.ItemData.addItem(item.Id);
        }
        SaveMng.ItemData.save();
    }

    /// <summary>
    /// 消費アイテム追加
    /// </summary>
    [MenuItem("Custom/debug/allData/Item/Consumable")]
    public static void itemConsumable() {
        SaveMng.Items.Clear();

        foreach (var item in ItemMast.List.Where(it=>it.Category==ItemMast.CATEGORY.CONSUMABLE)) {
            SaveMng.ItemData.addItem(item.Id);
        }
        SaveMng.ItemData.save();
    }

    [MenuItem("Custom/debug/allData/Archive")]
    public static void allArchive() {

        StoryListMast.load();

        for (int i = 0; i < StoryListMast.List.Length; i++) {
            SaveMng.Status.addArchive(StoryListMast.List[i].Id);
        }
        SaveMng.Status.save();

    }
    [MenuItem("Custom/debug/allData/Quest")]
    public static void allQuest() {

        StageMast.load();

        for (int i = 0; i < StageMast.List.Length; i++) {
            SaveMng.Status.ClearStage.Add(StageMast.List[i].Id);
        }
        SaveMng.Status.save();
    }
    [MenuItem("Custom/debug/allData/Member")]
    public static void allMember() {
        for (int i = 0; i < UnitMast.List.Count(); i++) {
            UnitStatusTran tran = UnitMast.getUnit(UnitMast.List[i].Id);
            if (!SaveMng.Units.Exists(it => it.MasterId == tran.MasterId)) {
                SaveMng.Units.Add(tran);
            }
        }
        SaveMng.saveUnit();
    }

    //////EditCommand///////////////////////////////////////
    [MenuItem("Custom/debug/DebugController")]
    public static void DebugController() {
        EditorWindow window = EditorWindow.GetWindow(typeof(debugControllWindow), false, "Debug Window");
        window.Show();
    }

    [MenuItem("Custom/debug/Simulator")]
    public static void DebugSimulatorController() {
        EditorWindow window = EditorWindow.GetWindow(typeof(debugSimulatorWindow), false, "Simulator");
        window.Show();
    }

    

    ////// Window///////////////////////////////////////
    public class debugControllWindow : EditorWindow {

        string InputLevel = "";

        private Vector2 _scrollPosition = Vector2.zero;
        void OnGUI() {

            _scrollPosition = EditorGUILayout.BeginScrollView(_scrollPosition);

            GUILayout.Space(10f);
            if (GUILayout.Button("ストーリーリロード", GUILayout.Height(30f))) {
                BaseStorySceneMng.Singleton.loadData();
            }
            GUILayout.Space(10f);
            if (GUILayout.Button("全ステージ発見", GUILayout.Height(30f))) {
                SaveMng.Status.DiscoveryStage.Clear();
                Array.ForEach(StageMast.List, it => SaveMng.Status.DiscoveryStage.Add(it.Id));
                SaveMng.Status.save();
            }
            GUILayout.Space(10f);
            if (GUILayout.Button("全ステージクリア", GUILayout.Height(30f))) {
                SaveMng.Status.ClearStage.Clear();
                Array.ForEach(StageMast.List, it => SaveMng.Status.ClearStage.Add(it.Id));
                SaveMng.Status.save();
            }
            GUILayout.Space(10f);
            if (GUILayout.Button("全ユニット合流", GUILayout.Height(30f))) {
                foreach( var unit in UnitMast.List) {
                    UnitStatusTran unit_tran = UnitMast.getUnit(unit);
                    unit_tran.Tactics = AiProc.TACTICS.COMMAND;
                    SaveMng.Units.Add(unit_tran);
                    SaveMng.Status.resetPartyAll(unit_tran.Id);
                }
                SaveMng.saveUnit();
            }
            GUILayout.Space(10f);
            if (GUILayout.Button("全アイテム取得", GUILayout.Height(30f))) {
                SaveMng.Items.Clear();
                foreach (var item in ItemMast.List) {
                    SaveMng.ItemData.addItem(item.Id);
                }
                SaveMng.ItemData.save();
            }
            GUILayout.Space(10f);
            if (GUILayout.Button("全アーカイブ取得", GUILayout.Height(30f))) {
                SaveMng.Status.Archives.Clear();
                foreach (var story in StoryListMast.List) {
                    SaveMng.Status.addArchive(story.Id);
                }
                SaveMng.Status.save();
            }

            GUILayout.Space(10f);
            GUILayout.Label("レベル");
            InputLevel = GUILayout.TextField(InputLevel);
            if (GUILayout.Button("レベル設定", GUILayout.Height(30f))) {
                int level = int.Parse(InputLevel);
                foreach (UnitStatusTran unit in SaveMng.Units) {
                    unit.setLevel(level);
                }
                SaveMng.UnitData.save();
            }
            GUILayout.Space(10f);
            if (GUILayout.Button("+10000 Money", GUILayout.Height(30f))) {
                SaveMng.Status.addMoney(10000);
                SaveMng.Status.save();
            }
            GUILayout.Space(10f);
            //GUILayout.Label("クエストID");
            //QuestId = GUILayout.TextField(QuestId);
            //if (GUILayout.Button("クエスト開始", GUILayout.Height(40f))) {
            //    int quest = int.Parse(QuestId);
            //    QuestSceneMng.questInit(quest);
            //    SaveMng.Status.save();
            //}

            if (GUILayout.Button("バトル勝利", GUILayout.Height(30f))) {
                BattleSceneMng.Singleton.forceResultProcess();
            }
            if (GUILayout.Button("HPMP回復", GUILayout.Height(30f))) {
                SaveMng.Units.ForEach(it => it.Status.Hp = it.MaxHp);
                SaveMng.Units.ForEach(it => it.Status.Mp = it.MaxMp);
                SaveMng.UnitData.save();
                SaveMng.Quest.ActiveParty.ForEach(it => it.Status.Hp = it.MaxHp);
                SaveMng.Quest.ActiveParty.ForEach(it => it.Status.Mp = it.MaxMp);
                SaveMng.Quest.save();
            }

            EditorGUILayout.EndScrollView();
        }
    }

    public class debugSimulatorWindow : EditorWindow
    {
        string EnemyMapId = "";
        int FieldSize = 6;
        int EnemyLevel = 0;

        string DropLv = ""; //ドロップ

        void OnGUI() {
            GUILayout.Label("敵ID");
            EnemyMapId = GUILayout.TextField(EnemyMapId);
            GUILayout.Label("敵レベル");
            EnemyLevel = int.Parse(GUILayout.TextField(EnemyLevel.ToString()));
            GUILayout.Label("フィールドサイズ");
            FieldSize = int.Parse(GUILayout.TextField(FieldSize.ToString()));
            if (GUILayout.Button("バトル開始", GUILayout.Height(30f))) {

                //EditorRoutineClass routine = new EditorRoutineClass();
                //routine.StartBattleEmurator(EnemysId, EnemyLevel);

                //バトルシーン編集中に起動すると設定を読み込む前にバトルシーンになるため、いったん別シーン挟む
                //string path = "Assets/Scenes/BattleScene.unity";//+ CmnConst.SCENE.NowLoadingScene.ToString();// “Assets/Scenes/SampleScene.unity”;
                //SceneAsset sceneAsset = AssetDatabase.LoadAssetAtPath<SceneAsset>(path);
                //EditorSceneManager.playModeStartScene = sceneAsset;

                if (!EditorApplication.isPlaying) {
                    EditorApplication.EnterPlaymode();
                }

                SaveMng.Quest.ActiveParty = SaveMng.Status.getActiveMembers();

                //if (EditorApplication.isPlaying)
                {
                    int enemyMap = int.Parse(EnemyMapId);
                    //int field = int.Parse(FieldSize);
                    SaveMng.Quest.Enemys = EnemyEncountMast.encount(enemyMap, FieldSize);
                    SaveMng.Quest.save();
                }

                //yield return new WaitForSeconds(1f);

                SceneManagerWrap.LoadAndNowLoading(CmnConst.SCENE.BattleScene);
            }

            GUILayout.Space(10);
            EditorGUILayout.BeginHorizontal();
            GUILayout.Label("ドロップレベル");
            DropLv = GUILayout.TextField(DropLv);
            
            if (GUILayout.Button("アイテムドロップ", GUILayout.Height(30f))) {

                SaveMng.Quest = new QuestTran();
                for (int i = 0; i < 5; i++) {
                    var item = ItemTran.getRandomItem(int.Parse(DropLv));
                    SaveMng.Quest.CarryBag.Add(item);
                }
                SaveMng.Quest.save();
                writeSave(SaveMng.Quest.GetType().Name);
            }
            EditorGUILayout.EndHorizontal();
        }
    }

    //ログインする
    public static void loginBeforeDay() {
        DateTime d = DateTime.Now;
        d = d.AddDays(-1);
        SaveMng.SysDt.LastLogin = d.ToBinary();
    }

    public static bool checkTSVRelation() {
        //
        //public static void relation() {
        //    //S mast
        //    List<int> ShopItemIds = ShopMast.List.Select(it => it.Id);
        //    //I mast
        //    var isan = ItemMast.List.FindAll(ShopItemIds.Contains);

        //    //List<string> fruitsList = list1.FindAll(list2.Contains);

        //    return isan;

        //}
        return false;
    }



#endif
}
