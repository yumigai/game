﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MakeTempMng : MonoBehaviour
{
    [SerializeField]
    private Transform Target;

    [SerializeField]
    private Camera Cam;

    // Start is called before the first frame update
    void Start()
    {
    }

    IEnumerator waitProcess() {
        yield return new WaitForEndOfFrame();
        yield return new WaitForSeconds(1f);
    }

    public void Test() {
        EffectControllMng.Singleton.showEffect(EffectControllMng.Key.Heal, Target.position);
        EffectControllMng.Singleton.showEffect(EffectControllMng.Key.Cure, Target.position);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
