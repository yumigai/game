﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SystemSceneMng : Base2DSceneMng
{
    [SerializeField]
    BaseConfigSceneMng ConfigScene;

    private void Awake() {
        pushCloseProcess = pushClose;
    }
    // Start is called before the first frame update
    new void Start()
    {
        base.Start();
    }

    public void pushClose() {
        if (ConfigScene.IsShowSaveBoard()) {
            ConfigScene.SaveBoard.closeWindow();
        } else {
            SceneManagerWrap.loadBefore();
        }
    }
}
