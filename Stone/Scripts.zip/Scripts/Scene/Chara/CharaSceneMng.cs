﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class CharaSceneMng : Base2DSceneMng
{
    public const int FONT_SIZE = 22;

    public const int SKILL_LIST_COST_INDEX = 0;

    public enum MODE
    {
        CHARA_VIEW,
        PARTY_EDIT,
    }

    //[SerializeField]
    //public CharaImgGropuMng ListItems;

    //[SerializeField]
    //public UnitDetailMng Info;

    //[SerializeField]
    //private GamePadListRecivMng Recive;

    [SerializeField]
    private UnitListMng UnitList;

    [SerializeField]
    private UnitDetailMng UnitDetail;

    [System.NonSerialized]
    public MODE ListMode = MODE.CHARA_VIEW;

    public static int SelectedDetail = -1;

    public static MODE ModeOrder = MODE.CHARA_VIEW;
    public static int ChangeBeforeMember = -1;

    public static CharaSceneMng Singleton;

    private int ChangeMember { get { return SaveMng.Status.ActiveMember[ChangeBeforeMember]; } set { SaveMng.Status.ActiveMember[ChangeBeforeMember] = value; } }

    private void Awake() {
        Singleton = this;
    }

    // Start is called before the first frame update
    new void Start()
    {
        base.Start();

        UnitDetail.gameObject.SetActive(false);

        ListMode = ModeOrder;

        UnitList.PushUnitCallback = pushSelectUnit;
        UnitList.PushCanselCallback = SceneManagerWrap.loadBefore;

    }

    //public void changeUnitSelect(CharaImgGaugeMng gauge) {
    //    var unit = SaveMng.Units.Where(it => it.Id == gauge.UnitTranId).FirstOrDefault();
    //    Info.setParams(unit);
    //}

    public void pushSelectUnit( CharaImgGaugeMng gauge ) {
        var unit = SaveMng.Units.Where( it => it.Id == gauge.UnitTranId).FirstOrDefault();
        UnitDetail.gameObject.SetActive(true);
        UnitDetail.setParams(unit);
        
    }

    public void pushCloseButton() {
        if ( ! UnitDetail.CloseItemBoard()) {
            //アイテムボードは開いていない
            if (UnitDetail.gameObject.activeSelf) {
                UnitDetail.gameObject.SetActive(false);
            } else {
                SceneManagerWrap.loadBefore();
            }
        }
    }
}
