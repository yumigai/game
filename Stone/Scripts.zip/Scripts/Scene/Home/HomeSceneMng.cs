﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HomeSceneMng : BaseHomeSceneMng
{
    [SerializeField]
    private Text RestTimeLimit;

    // Start is called before the first frame update
    new void Start()
    {
        base.Start();
        initProcess();
    }

    void initProcess() {
        RestTimeLimit.text = SaveMng.Status.RestTimeLimit.ToString();
    }
}
