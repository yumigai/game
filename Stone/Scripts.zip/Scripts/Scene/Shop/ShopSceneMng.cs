﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShopSceneMng : BaseShopSceneMng
{
    [SerializeField]
    private ItemBoardMng ItemBoard;

    private void Awake() {
        ItemBoardMng.OrderMode = ItemBoardMng.MODE.BUY;
        ItemBoard.CallbackClose = ExitShop;
    }

    // Start is called before the first frame update
    void Start()
    {
        //base.Start();
        ItemBoard.showShopItems();
        
    }

    void ExitShop() {
        SceneManagerWrap.loadBefore();
    }
}
