﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemSceneMng : Base2DSceneMng
{
    [SerializeField]
    public GameObject SceneBase;

    public static ItemSceneMng Singleton;

    void Awake() {
        
        Singleton = this;
        init();
    }

    new private void Start() {
        base.Start();
        init();
    }

    protected void init() {
        SceneBase.SetActive(SceneManagerWrap.NowScheneIs(GameConst.SCENE.ItemScene));
    }
}
