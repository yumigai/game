﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class StageSelectScneneMng : MonoBehaviour
{
    [SerializeField]
    private MultiUseScrollMng AreaLists;

    [SerializeField]
    private GamePadListRecivMng ListRecive;

    [SerializeField]
    private GamePadListRecivMng Party;

    [SerializeField]
    private Image BackImage;

    [SerializeField]
    private Text AreaName;

    public static int SelectedChapterId = 1;


    private void Start() {

        //ButtonGuidMng.initButton(
        //    new CmnConfig.GamePadButton[] {
        //                        CmnConfig.GamePadButton.Decision, CmnConfig.GamePadButton.Cancel, CmnConfig.GamePadButton.Y, CmnConfig.GamePadButton.R1, CmnConfig.GamePadButton.L1 },
        //            new string[] { "decision", "return", "party edit", "party switching", "" },
        //            new string[] { "決定", "戻る", "パーティ編成", "パーティ切替", "" }
        //    );

        var list = StageMast.List
            .Where(it => SaveMng.Status.DiscoveryStage.IndexOf(it.Id) >= 0)
            .Where(it => it.ChapterId == SelectedChapterId)
            .OrderByDescending(it => it.GetPriority())
            .ToArray();

        List<MultiUseListMng> mngs = AreaLists.makeList(list);
        foreach (var mng in mngs) {
            mng.Callback = pushStage;
        }

        ListRecive.initSetupWithFrameEnd();

        var chapter = ChapterMast.List.FirstOrDefault(it => it.Id == SelectedChapterId);
        if (chapter != null) { // 基本的にnullになる事はない
            BackImage.sprite = Resources.Load<Sprite>(CmnConst.Path.IMG_BACKGROUND + chapter.ImagePath);
            AreaName.text = chapter.Name;
        }

        StartCoroutine(setupFrameEnd());

    }

    /// <summary>
    /// フレーム最後のセットアップ
    /// </summary>
    /// <returns></returns>
    private IEnumerator setupFrameEnd() {
        yield return new WaitForEndOfFrame();
        Party.changeButtonsOnOff(false);
    }

    public void pushStage(MultiUseListMng mng) {
        CommonProcess.showConfirm(mng.Name.text, pushJumpStageScene);
        StageFieldSceneMng.SelectedStage = StageMast.getStageIndex(mng.Id);// System.Array.FindIndex(StageMast.List, it => it.Id == mng.Id);
    }

    public void pushReturn() {
        if (ListRecive.isActiveThis()) {
            SceneManagerWrap.loadBefore();
        } else {
            GamePadListRecivMng.ActiveGamePadList = ListRecive;
        }
    }

    public void pushJumpStageScene(object obj) {

        //switch()

        SaveMng.Quest.Init(StageFieldSceneMng.SelectedStage, SaveMng.Status.getActiveMembers());
        SceneManagerWrap.LoadAndNowLoading(CmnConst.SCENE.QuestScene);
    }
}