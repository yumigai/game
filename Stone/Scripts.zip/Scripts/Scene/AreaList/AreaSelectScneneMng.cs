﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

public class AreaSelectScneneMng : Base2DSceneMng
{
    [SerializeField]
    private MultiUseScrollMng AreaLists;

    [SerializeField]
    private GamePadListRecivMng ListRecive;

    [SerializeField]
    private Image AreaImage;

    [SerializeField]
    private Text AreaName;

    [SerializeField]
    private Text AreaInfo;


    private void Start() {

        var chapter_ids = StageMast.List.Where(it => SaveMng.Status.DiscoveryStage.IndexOf(it.Id) >= 0).Select(it => it.ChapterId).Distinct();

        var list = ChapterMast.List
            .Where(it => chapter_ids.Contains(it.Id))
            .OrderByDescending(it=>it.GetPriority())
            .ToArray();

        List<MultiUseListMng> mngs = AreaLists.makeList(list);
        foreach (var mng in mngs) {
            mng.Callback = pushList;
            mng.SelectedCallback = changeSelect;
        }
 
        ListRecive.initSetupWithFrameEnd();

    }

    public void pushList(MultiUseListMng mng) {
        StageSelectScneneMng.SelectedChapterId = mng.Id;
        SceneManagerWrap.LoadScene(CmnConst.SCENE.StageSelectScene);
    }

    /// <summary>
    /// 選択に伴う背景画像の変更
    /// </summary>
    /// <param name="mng"></param>
    public void changeSelect(MultiUseListMng mng) {

        StartCoroutine(setAreaImage( CmnConst.Path.IMG_BACKGROUND + mng.ImagePath ));
        AreaName.text = mng.Name.text;
        AreaInfo.text = mng.Detail.text;
    }

    private IEnumerator setAreaImage(string path) {

        ResourceRequest res = Resources.LoadAsync<Sprite>(path);
        for (int i = 0; i < 100 && !res.isDone; i++ ) {
            yield return new WaitForEndOfFrame();
        }
        AreaImage.sprite = res.asset as Sprite;
    }

}
