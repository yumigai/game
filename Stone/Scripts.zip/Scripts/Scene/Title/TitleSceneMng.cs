﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TitleSceneMng : BaseTitleSceneMng
{
    [SerializeField]
    private GameObject PressAnyKey;

    [SerializeField]
    private Transform SaveParent;

    [SerializeField]
    private GameObject SelectMode;

    [SerializeField]
    private SaveBoardMng SaveBoard;

    [SerializeField]
    private GameObject NewGameButton;

    [SerializeField]
    private GameObject ContinueButton;

    [SerializeField]
    private GameObject LoadButton;

    // Start is called before the first frame update
    new void Start() {
        base.Start();

        SelectMode.SetActive(false);

        //UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(ContinueGameButton);
    }

    // Update is called once per frame
    //void Update()
    //{
    //    if (!SelectMode.activeSelf && !SaveBoardMng.IsShowSaveBoard()) {
    //        if (Input.anyKeyDown) {
    //            pushAnyKey();
    //        }
    //    }
    //}

    public void pushTitleStart() {
        PressAnyKey.SetActive(false);
        SelectMode.SetActive(true);
        StartCoroutine(SetDefaultMode());
    }

    public IEnumerator SetDefaultMode() {

        UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(null);
        if (SaveMng.isEmpty()) {
            //初回は NewGameのみ表示
            ContinueButton.SetActive(false);
            LoadButton.SetActive(false);
            yield return new WaitForEndOfFrame();
            UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(NewGameButton);
        } else {
            yield return new WaitForEndOfFrame();
            UnityEngine.EventSystems.EventSystem.current.SetSelectedGameObject(ContinueButton);
        }
    }

    public void pushNewGame() {
        if (SaveMng.isEmpty()) {
            pushStart();
        } else {
            string txt = SaveMng.IsJp ? "新規でゲームを開始します。\nオートセーブが上書きされますがよろしいですか？" : "Start a new game.\nAuto-save will be overwritten, are you sure?";
            CommonProcess.showConfirm(txt, (obj) => {
                SaveMng.resetSlotAll();
                pushStart();
            });
        }

    }
    public void pushContinue() {
        pushStart();
    }

    public void pushLoad() {
        SaveBoard.showLoadBoard(SaveParent);
    }

    public void pushDebug() {
        SceneManagerWrap.loadScene("DebugMultiScene");
    }
}