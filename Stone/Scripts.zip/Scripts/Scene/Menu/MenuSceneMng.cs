﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuSceneMng : Base2DSceneMng
{

    [SerializeField]
    private MenuMng Menu;

    [SerializeField]
    private GameObject SourceGameBase; //呼び出し元のゲームオブジェクト

    [SerializeField]
    private GameObject MenuBase;


    public static MenuSceneMng Singleton;

    private void Awake() {
        if (!SceneManagerWrap.NowScheneIs(CmnConst.SCENE.MenuScene)) {
            MenuBase.SetActive(false);
        }
        pushCloseProcess = pushClose;
        Singleton = this;
    }
    // Start is called before the first frame update
    new void Start(){
        base.Start();
    }

    /// <summary>
    /// 
    /// </summary>
    /// <param name="source">呼び出し元ゲームオブジェクト</param>
    public void showMenu(GameObject source) {
        SourceGameBase = source;
        SourceGameBase.SetActive(false);
        showMenu();
    }

    public void showMenu() {
        MenuBase.SetActive(true);
    }

    public void pushClose() {

        if (Menu.menuClose()) {
            closeMenuScene();
        } 
    }

    private void closeMenuScene() {
        if (SceneManagerWrap.NowScheneIs(CmnConst.SCENE.MenuScene)) {
            SceneManagerWrap.loadBefore();
        } else {
            if (SourceGameBase != null) {
                SourceGameBase.SetActive(true);
            }
            MenuBase.SetActive(false);
        }
    }

    public void hideMenu() {
        MenuBase.SetActive(false);
    }
}
