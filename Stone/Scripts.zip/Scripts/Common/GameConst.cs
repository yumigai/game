﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public partial class GameConst : CmnConst
{


    public const string MAP_MATERIAL_PATH = "Material/Map/";
    public const string BACK_MATERIAL_PATH = MAP_MATERIAL_PATH;


    public enum ELEMENT
    {
        Non,
        Material,
        Fire,
        Ice,
        Thunder,
        Wind,
        Earth,
        All
    }

    public static string[] ELEMENT_JP = new string[(int)ELEMENT.All] {
        "無",
        "物",
        "炎",
        "氷",
        "雷",
        "風",
        "土",
    };

    public static string[] ELEMENT_EN = new string[(int)ELEMENT.All] {
        "Force",
        "Physical",
        "Fire",
        "Ice",
        "Thunder",
        "Wind",
        "Earth",
    };

    /// <summary>
    /// 効果（視覚的な意味に限定しない）
    /// </summary>
    public enum SPEC
    {
        ATTACK,
        DEFENCE,
        HEAL,
        RESURRECT,
        STATUS_BUFF,
        STATUS_DEBUFF,
        BUFF_REMOVE,
        DEBUFF_REMOVE,
        ENCHANT_ELEMENT,
        STAN,
        CURE_STAN,
        POISON,
        CURE_POISON,
        CURE_BAD, //毒・麻痺回復
        ALL,
    }

    ///// <summary>
    ///// エフェクトビジュアル
    ///// ※タグ名と合わせるため、大文字じゃなくてキャメルケース
    ///// </summary>
    //public enum EffectVisual 
    //{
    //    Blow,
    //    Claw,
    //    Fang,
    //    Slash,
    //    Stab,
    //    Arrow,
    //    Gun,
    //    Fire,
    //    Explode,
    //    Thunder,
    //    Ice,
    //    HealHp,
    //    HealMp,
    //    HealDual,
    //    Resurrect,
    //    Buff,
    //    Debuff,
    //    Poison,
    //    Stan,
    //    CureBad,
    //    All
    //}

    /// <summary>
    /// レアリティ
    /// </summary>
    public enum RARITY
    {
        N,
        R,
        SR,
        SSR,
        UR,
        ALL
    }

    new public readonly static string[] RARITY_COLOR = new string[(int)RARITY.ALL] {
        "FFFFFF",
        "B24D27",
        "00B3FF",
        "9D00FF",
        "FF0000"
    };

    //ルーンを付与する場合のアイテム最低レアリティ
    public const RARITY RUNE_MINIMAM_RARITY = RARITY.R;

    //複数ルーンを付与する場合の最低レアリティ
    public const RARITY RUNE_MULTI_RARITY = RARITY.SSR;

    ///// <summary>
    ///// N相当のドロップ確率
    ///// </summary>
    //public const float BASE_RARITY_PERCENT = 70;

    ///// <summary>
    ///// Nから減少するドロップ確率（）
    ///// </summary>
    //public const float RARITY_UP_RATIO = 3;

    /// <summary>
    /// レア度別ドロップ確率
    /// </summary>
    public readonly static float[] RARITY_PERCENT = new float[(int)RARITY.ALL] {
        70,
        25,
        9,
        3,
        1
    };

    /// <summary>
    /// カテゴリ別ドロップ率
    /// </summary>
    new public static readonly float[] DROP_CATEGORY_PERCENT
        = new float[(int)ItemMast.CATEGORY.ALL] {
            0, //UNNOWN
            10, //WEAPON
            10, //ARMOR
            15, //ACCESSORY
            25, //CONSUMABLE
            30, //MATERIAL
            0, //ANY
        };


    public class Scene
    {
        public static string CharaScene = "CharaScene";
        public static string ItemMenu = "ItemMenuScene";
        public static string World = "WorldListScene";
    }

    public const string MONEY_CURRENCY = "$";

    //ログイン日数によるメンバー加入
    public const bool IS_ASSIGN_TIME = false;

    public const string DUNGEON_SECTION_PREFAB = Path.PREFAB + "Dungeon/";

    public const string HEROS_NAME = "勇者";

    public const string ENEMY_NAME = "モンスター";

    public const string DEFAULT_PLAYER_NAME = "アガタ";

    public const string DEFAULT_PLYAER_NAME_EN = "Agata";

    //ユニットの最初はプレイヤー自身を表すか（基本的にここはtrue。捻ったシステムにする場合に必要な場合だけfalse）
    //public const bool FIRST_UNIT_IS_PLAYER = true;

    //名前変更機能がある場合、主人公以外の名前も変更できるか
    public const bool CAN_CHANGE_NAME_ALL = false;

    //アイテム同種最大
    public const int MAX_ITEM_NUM = 9;

    //アイテム種類別所持最大
    public const int MAX_ITEM_KIND_NUM = 99;

    //アイテム取得基本確率
    public const float BASE_GET_ITEM_PERCENT = 100;

    //ルーン取得基本確率
    public const float BASE_GET_RUNE_PERCENT = 25;

    //装備品ルーン最大数
    public const int MAX_RUNE_EQUIP = 2;

    //アクセサリルーン最大数
    public const int MAX_RUNE_ACCESSORY = 2;

    //ゲームシステム的にタイムリミットがあるか
    public const bool IS_TIME_LIMIT_SYSTEM = true;

    //タイムリミットが回復しない場合、デフォルトの値
    public const int DEFAULT_TIME_LIMIT = 30;

}